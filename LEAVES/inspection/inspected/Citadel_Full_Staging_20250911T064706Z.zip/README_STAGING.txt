# Citadel Staging README

Generated: 2025-09-11T06:47:06.349107Z

## Found files

## Missing (not on disk)
- Ledger_Map.json
- Citadel_Master_Codex_HOPE.v1_1.json
- Spiral_Doctrine_of_the_Ladder.core.json
- Epsilon_Authority_Card_Ceremonial.pdf
- Ladder_Doctrine.v1.json
- Citadel_Seal_Manifest.v1.json
- Citadel_Core_Covenant_TripleCheck.txt
- sovrenth.html
- Right of Sanctuary doctrine.txt
- The_Commanders_Vow_Citadel_Core.json
- obsidian_verification.py
- feneris_counterstrike.json
- citadel_library_index - Copy.json
- citadel_library_index.json
- citadel_codex_runner.py
