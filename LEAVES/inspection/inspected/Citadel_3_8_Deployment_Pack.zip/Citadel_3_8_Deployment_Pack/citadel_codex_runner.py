#!/usr/bin/env python3
"""
Citadel Codex Runner
- Serves a small local web app to browse & search the Citadel library JSONs
- Or runs a CLI for quick searches (no external dependencies)
Files expected (same folder or specify --index/--cards):
  - citadel_library_index.json   (optional but recommended)
  - citadel_codex_cards.json     (required for rich metadata)
Usage:
  Web UI (default, requires Flask):
    python citadel_codex_runner.py
    python citadel_codex_runner.py --host 127.0.0.1 --port 8787
  CLI (no Flask needed):
    python citadel_codex_runner.py --cli search "Shadow Wall"
    python citadel_codex_runner.py --cli list
    python citadel_codex_runner.py --cli show CIT-005
"""

import argparse, json, os, sys, re, textwrap
from pathlib import Path

DEFAULT_INDEX = "citadel_library_index.json"
DEFAULT_CARDS = "citadel_codex_cards.json"

def load_json(path):
    p = Path(path)
    if not p.exists():
        return None
    with open(p, "r", encoding="utf-8") as f:
        return json.load(f)

def normalize(s):
    return re.sub(r"\s+", " ", (s or "")).strip().lower()

def search_cards(cards, query):
    q = normalize(query)
    res = []
    for c in cards:
        hay = " ".join([c.get("id",""), c.get("title",""), c.get("summary",""), " ".join(c.get("key_topics",[])), c.get("category","")])
        if q in normalize(hay):
            res.append(c)
    return res

def cli_mode(cards, index, args):
    if args.cli_command == "list":
        for c in cards:
            print(f"{c['id']:>7}  {c['title']}  [{c['category']}]")
        return 0
    elif args.cli_command == "search":
        if not args.term:
            print("Provide a search term, e.g. --cli search \"Shadow Wall\"")
            return 1
        hits = search_cards(cards, " ".join(args.term))
        if not hits:
            print("No matches.")
            return 0
        for c in hits:
            print(f"\n{c['id']} — {c['title']} [{c['category']}]")
            print(textwrap.fill(c.get("summary",""), width=80))
            if c.get("key_topics"):
                print("Topics:", ", ".join(c["key_topics"]))
            if c.get("origin_file"):
                print("File:", c["origin_file"])
        return 0
    elif args.cli_command == "show":
        if not args.term:
            print("Provide an ID, e.g. --cli show CIT-005")
            return 1
        target = args.term[0]
        for c in cards:
            if c.get("id") == target:
                print(json.dumps(c, indent=2))
                return 0
        print("Not found.")
        return 1
    else:
        print("Unknown CLI command. Use: list | search | show")
        return 1

def try_web_mode(cards, index, host, port):
    try:
        from flask import Flask, render_template_string, request, send_from_directory
    except Exception as e:
        print("[info] Flask not available. Use --cli for command-line mode.")
        print("       pip install flask   # to enable the web UI")
        return 1

    app = Flask(__name__)

    TEMPLATE = r"""
<!doctype html>
<html>
<head>
  <meta charset="utf-8"/>
  <title>Citadel Codex</title>
  <meta name="viewport" content="width=device-width,initial-scale=1"/>
  <style>
    :root { --bg:#0b1020; --fg:#e8eefc; --muted:#9bb0d6; --card:#141a33; --acc:#8aa2ff; }
    body { background:var(--bg); color:var(--fg); font-family: ui-sans-serif, system-ui, -apple-system, Segoe UI, Roboto, Helvetica, Arial; margin:0; }
    header { padding:16px 20px; border-bottom:1px solid #243055; position:sticky; top:0; background:linear-gradient(180deg, rgba(11,16,32,.95), rgba(11,16,32,.8)); backdrop-filter: blur(6px); }
    h1 { margin:0; font-size:20px; letter-spacing:.5px; }
    .container { max-width:1100px; margin:0 auto; padding:20px; }
    .search { display:flex; gap:10px; margin:16px 0 8px; }
    input[type=text] { flex:1; padding:12px 14px; border-radius:12px; border:1px solid #2b3866; background: #0e1430; color:var(--fg); }
    button { padding:12px 16px; border-radius:12px; border:1px solid #2b3866; background:#17224a; color:var(--fg); cursor:pointer; }
    button:hover { background:#1d2a5c; }
    .grid { display:grid; grid-template-columns: repeat(auto-fit, minmax(260px, 1fr)); gap:14px; margin-top:12px; }
    .card { background:var(--card); border:1px solid #22305a; border-radius:16px; padding:14px; display:flex; flex-direction:column; gap:8px; }
    .badge { font-size:12px; color:var(--muted); }
    .title { font-weight:700; }
    .topics { font-size:12px; color:var(--muted); }
    .linkbar { display:flex; gap:10px; margin-top:auto; }
    a.btn { text-decoration:none; color:var(--fg); background:#22305a; border:1px solid #30407a; padding:8px 10px; border-radius:10px; font-size:14px; }
    a.btn:hover { background:#2a478e; }
    .muted { color:var(--muted); font-size:12px; }
    footer { text-align:center; color:#7d90c7; padding:20px; }
  </style>
</head>
<body>
<header>
  <h1>Citadel Codex — Library Runner</h1>
  <div class="container">
    <form class="search" method="GET" action="/">
      <input type="text" name="q" placeholder="Search titles, topics, or summaries…" value="{{q|e}}"/>
      <button type="submit">Search</button>
      <a class="btn" href="/">Reset</a>
    </form>
    <div class="muted">{{count}} item(s) {{ 'matched' if q else 'loaded' }}</div>
  </div>
</header>
<div class="container">
  <div class="grid">
    {% for c in cards %}
    <div class="card">
      <div class="badge">{{ c.category }}</div>
      <div class="title">{{ c.id }} — {{ c.title }}</div>
      <div class="summary">{{ c.summary }}</div>
      {% if c.key_topics %}<div class="topics">Topics: {{ ", ".join(c.key_topics) }}</div>{% endif %}
      <div class="linkbar">
        {% if c.origin_file %}
          <a class="btn" href="/open/{{ c.origin_file }}">Open File</a>
        {% endif %}
        <a class="btn" href="/api/card/{{ c.id }}">JSON</a>
      </div>
    </div>
    {% endfor %}
  </div>

  <h3 style="margin-top:28px;">Raw Index & API</h3>
  <ul>
    <li><a class="btn" href="/api/cards">GET /api/cards</a></li>
    <li><a class="btn" href="/api/index">GET /api/index</a></li>
  </ul>
</div>
<footer>Built for the Commander. Memory is sacred.</footer>
</body>
</html>
    """

    CARDS = cards or []
    INDEX = index or []

    @app.route("/")
    def home():
        q = request.args.get("q","").strip()
        results = CARDS
        if q:
            results = search_cards(CARDS, q)
        return render_template_string(TEMPLATE, cards=results, q=q, count=len(results))

    @app.route("/api/cards")
    def api_cards():
        return CARDS

    @app.route("/api/index")
    def api_index():
        return INDEX

    @app.route("/api/card/<cid>")
    def api_card(cid):
        for c in CARDS:
            if c.get("id") == cid:
                return c
        return {"error":"not found"}, 404

    @app.route("/open/<path:filename>")
    def open_file(filename):
        # Serve files from current directory where JSONs and docs reside
        # Security note: for local use only.
        base = Path(".").resolve()
        file_path = (base / filename).resolve()
        if not str(file_path).startswith(str(base)):
            return "Invalid path", 400
        if not file_path.exists():
            return "File not found", 404
        return send_from_directory(base, filename, as_attachment=False)

    print(f"[web] running at http://{host}:{port}")
    app.run(host=host, port=port, debug=False)
    return 0

def main():
    parser = argparse.ArgumentParser(description="Citadel Codex Runner")
    parser.add_argument("--index", default=DEFAULT_INDEX, help="Path to citadel_library_index.json")
    parser.add_argument("--cards", default=DEFAULT_CARDS, help="Path to citadel_codex_cards.json")
    parser.add_argument("--host", default="127.0.0.1")
    parser.add_argument("--port", default=8787, type=int)
    parser.add_argument("--cli", action="store_true", help="Run in CLI mode (no Flask needed)")
    parser.add_argument("cli_command", nargs="?", help="CLI: list | search | show")
    parser.add_argument("term", nargs="*", help="CLI: search terms or show <ID>")
    args = parser.parse_args()

    cards = load_json(args.cards) or []
    index = load_json(args.index) or []

    if args.cli:
        if not cards:
            print("No cards loaded. Ensure citadel_codex_cards.json exists or pass --cards path.")
            return 1
        return cli_mode(cards, index, args)
    else:
        # Web mode preferred
        return try_web_mode(cards, index, args.host, args.port)

if __name__ == "__main__":
    raise SystemExit(main())
