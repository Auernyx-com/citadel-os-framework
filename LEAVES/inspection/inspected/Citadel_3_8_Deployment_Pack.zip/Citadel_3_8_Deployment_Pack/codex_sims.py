
#!/usr/bin/env python3
"""Codex 3.8 Sims — stability & integrity checks.
Run:
  python codex_sims.py triplecheck
  python codex_sims.py drift
  python codex_sims.py runner-smoke
"""
import sys, json, hashlib, os
from pathlib import Path

ROOT = Path(__file__).parent.resolve()

def sha256sum(path: Path):
    h = hashlib.sha256()
    with open(path, "rb") as f:
        for chunk in iter(lambda: f.read(1024*1024), b""):
            h.update(chunk)
    return h.hexdigest()

def ok(msg): print("[OK] " + msg)
def miss(msg): print("[MISS] " + msg)
def warn(msg): print("[WARN] " + msg)
def fail(msg): print("[FAIL] " + msg)

def triplecheck():
    required = [
        "Citadel_Codex_Bundle.v1.json",
        "citadel_codex_cards.json",
        "citadel_library_index.json",
        "Citadel_Seal_Manifest.v1.json",
        "Ladder_Doctrine.v1.json",
        "Spiral_Doctrine_of_the_Ladder.core.json",
        "The_Commanders_Vow_Citadel_Core.json"
    ]
    for name in required:
        p = ROOT / name
        (ok if p.exists() else miss)(f"artifact: {name}")
    # Clauses sanity
    seal_path = ROOT / "Citadel_Seal_Manifest.v1.json"
    if seal_path.exists():
        try:
            data = json.loads(seal_path.read_text(encoding="utf-8"))
            clauses = set(data.get("clauses", []))
            needed = ('Right of Sanctuary applies at ingress.', 'Triple Verification required before any strike.', 'Kintsugi ethic: repair with record; do not erase history.')
            if needed.issubset(clauses):
                ok("seal clauses present")
            else:
                warn("seal clauses incomplete")
        except Exception as e:
            fail(f"seal parse error: {e}")

def drift():
    baseline_path = ROOT / "codex_baseline_checksums.json"
    if not baseline_path.exists():
        fail("baseline file missing"); return
    baseline = json.loads(baseline_path.read_text(encoding="utf-8"))
    any_diff = False
    for name, expected in baseline.items():
        p = ROOT / name
        if not p.exists():
            miss(f"missing: {name}"); any_diff = True; continue
        cur = sha256sum(p)
        if cur != expected:
            warn(f"hash drift: {name}")
            any_diff = True
        else:
            ok(f"hash stable: {name}")
    if not any_diff:
        ok("no drift detected")

def runner_smoke():
    # Minimal check: cards and index are readable JSON
    for name in ["citadel_codex_cards.json", "citadel_library_index.json"]:
        p = ROOT / name
        try:
            json.loads(p.read_text(encoding="utf-8"))
            ok(f"json readable: {name}")
        except Exception as e:
            fail(f"json invalid: {name} -> {e}")

def main():
    cmd = sys.argv[1] if len(sys.argv) > 1 else "triplecheck"
    if cmd == "triplecheck": triplecheck()
    elif cmd == "drift": drift()
    elif cmd == "runner-smoke": runner_smoke()
    else:
        print("usage: triplecheck | drift | runner-smoke")

if __name__ == "__main__":
    main()
